//
//  NotesListViewController+Additions.h
//  UnCloudNotes
//
//  Created by Saul Mora on 6/17/14.
//  Copyright (c) 2014 Ray Wenderlich. All rights reserved.
//

@import UIKit

@interface NotesListViewController (Additions)

- (IBAction) unwindToNotesList:(UIStoryboardSegue *)segue;

@end